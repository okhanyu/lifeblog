---
title: "我是分类第三篇"
date: 2020-08-02T22:41:19+08:00
draft: false
categories: 科技
tags: ["随想"]
attendpos: category_list_item
attendbg: http://pic1.win4000.com/wallpaper/a/58f467b96eb45.jpg
attendicon: green
---

