---
title: "我是分类第二篇"
date: 2020-08-02T22:41:02+08:00
draft: false
categories: 创意
tags: ["随想"]
attendpos: category_list_item
attendbg: https://static.is26.com/uploads/2020/04/desk-21-2.jpeg
attendicon: red
---

